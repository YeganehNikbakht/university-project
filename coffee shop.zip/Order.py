
# Import the menu dictionary
from Menu import menu

# Store customer orders
orders = []


# Add a new order
def add_order():

    product = input("Enter product name: ").lower()

    if product not in menu:
        print("Sorry! This product is not available.")
        return

    try:
        quantity = int(input("Enter quantity: "))

        if quantity <= 0:
            print("Quantity must be greater than zero.")
            return

    except ValueError:
        print("Please enter a valid number.")
        return

    order = {
        "product": product,
        "price": menu[product],
        "quantity": quantity
    }

    orders.append(order)

    print("Order added successfully!")


# Display all orders
def show_orders():

    if len(orders) == 0:
        print("No orders have been registered yet.")
        return

    print("\n========== Your Orders ==========")

    for order in orders:

        print("Product:", order["product"])
        print("Price:", f'{order["price"]:,}', "Toman")
        print("Quantity:", order["quantity"])
        print("---------------------------------")
