
# Import orders from Order.py
from Order import orders


# Calculate the total price
def calculate_total():

    total = 0

    for order in orders:

        price = order["price"]
        quantity = order["quantity"]

        total += price * quantity

    return total


# Calculate the discount
def calculate_discount(total):

    if total > 1000000:
        discount = total * 0.10
    else:
        discount = 0

    return discount


# Print the final invoice
def print_invoice():

    if len(orders) == 0:
        print("No orders available to print an invoice.")
        return

    total = calculate_total()
    discount = calculate_discount(total)
    final_amount = total - discount

    print("\n========== Final Invoice ==========")

    for order in orders:

        product = order["product"]
        quantity = order["quantity"]
        price = order["price"]

        subtotal = price * quantity

        print("Product:", product)
        print("Quantity:", quantity)
        print("Subtotal:", f"{subtotal:,}", "Toman")
        print("-----------------------------------")

    print("Total amount:", f"{total:,}", "Toman")
    print("Discount:", f"{discount:,.0f}", "Toman")
    print("Final amount:", f"{final_amount:,.0f}", "Toman")

    print("===================================")
